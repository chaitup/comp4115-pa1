select customerNumber from customers where customerNumber In (select cust
omerNumber from payments where amount>100000);
select orderNumber,productCode from orderdetails where orderNumber IN(sel
ect orderNumber from orders where status="ON Hold");
select FirstName, LastName from employees JOIN offices ON offices.officeC
ode=employees.officeCode where JobTitle="SalesManager";
select customerNumber,officeCode from customers JOIN offices ON customers
.country=offices.country;
select contactFirstName, contactLastName from customers where customerNum
ber IN (select customerNumber from orders where orderDate>="2004-01-01");
select customerNumber from customers where country="USA" AND state!="CA";
select productVendor from products where productLine IN (select productLi
ne from productlines where products.productLine=productlines.productLine AND MSR
P-buyprice>100);
SELECT priceEach * quantityOrdered FROM orderdetails WHERE priceEach * quantityOrdered > 10000;


